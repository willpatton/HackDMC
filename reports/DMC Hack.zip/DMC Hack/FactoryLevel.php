<!DOCTYPE html>
<html>
<body>
<h1>Overall Factory View</h1>
<hr>
<h2>Factory Wattage</h2>
<br>
<img src="img/Percentage%20of%20watt%20factory.png" alt="Factory Wattage"  style="width:1000px;height:350px;">
<br>
<hr>
<h2>Total Wattage</h2>
<br>
<img src="img/Total%20of%20watt%20factory.png" alt="Total Wattage"  style="width:1000px;height:350px;">
<br>
<br>
<img src="img/Total%20of%20watt%20factory%20short.png" alt="Total Wattage Shorterx" style="width:1000px;height:350px;">
<br>
</body>
</html>