


<!DOCTYPE html>
<html>
<body>
<hr>
<h2>Machine Status</h2>
<br>
<?php
include 'Include_Plots/Status.html'; 
?>
<br>
<hr>
<h2>Machine Overrides</h2>
<br>
<?php
include 'Include_Plots/Override.html'; 
?>
</body>
</html>
